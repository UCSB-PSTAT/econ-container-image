#' NBER recessions as of April 2021
#' @source FRED
#' @format A data table created by a command something like
#' fromFred <- textConnection("Peak, Trough
#' 1857-06-01, 1858-12-01
#' 1860-10-01, 1861-06-01
#' 2020-02-01, NA")
#' recessions_df <- read.table(fromFred, sep=',',
#'                         colClasses=c('Date', 'Date'), header=TRUE)
"recessions_df"
