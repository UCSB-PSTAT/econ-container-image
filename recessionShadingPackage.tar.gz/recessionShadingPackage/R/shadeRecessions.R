# shadeRecessions.R

# idea taken from https://www.r-bloggers.com/2011/08/use-geom_rect-to-add-recession-bars-to-your-time-series-plots-rstats-ggplot/
# by Jeffrey Breen

# Dick Startz
# April 2021

# This function adds recession shading to the ggplot() object thePlot, which should have plotted an xts object
# where the x-axis is a Date named date.

# recessions is a dataframe with colClasses=c('Date', 'Date') and columns Peak and Trough
# recessions defaults to the object recessions.df

# The function requires library ggplot2

#' Add recession shading to graph
#'
#' @param thePlot A ggplot graph of an xts object
#' @param recessions A table of peaks and troughs, see recessions.df for an example
#' @param fill Color for recession shading
#' @param alpha Transparency
#' @return ggplot with shading
#' @export
#' @examples
#' g <- shadeRecessions(aggPlot)

shadeRecessions <- function(thePlot, recessions = recessions_df, fill='pink', alpha=0.2){
  if(is.na(recessions$Trough[nrow(recessions)])) recessions$Trough[nrow(recessions)] <- "2100-01-01" # in case last recession not over
  recessions.trim = subset(recessions, Peak >= min(thePlot$data$date) & Trough <= max(thePlot$data$date))
  thePlot <- thePlot + geom_rect(data=recessions.trim, aes(xmin=Peak, xmax=Trough, ymin=-Inf, ymax=+Inf), fill=fill, alpha=alpha)
  return(thePlot)
}
